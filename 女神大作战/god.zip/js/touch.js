var oGod={
	doc:document,
	overstr:['女神狠狠的鄙视了我！','女神怏怏的看了我一眼！','女神的小手拉了我一小下','女神给我唱了一首《好汉歌》','女神强吻了我!','女神···我，你懂的!'],
	goReady:function(){
	var myNum=0;
	var loadArr=["img/touchme1.png","img/touchme2.png","img/touchme3.png","img/touchme4.png","img/touchme5.png","img/touchme6.png","img/touchme7.png"];
	for (var i = 0; i < loadArr.length; i++) {
	var nImg=new Image();
	nImg.src=loadArr[i]
	nImg.onload=function(){
		myNum++;
		if(myNum==7){			
			oGod.gameBegin();
		}
	}
	};
	},

gameBegin:function(){	
	var oLoad=document.getElementById("loading");
	oLoad.style.display="none";
	
	var oWrap=oGod.doc.getElementById("wrap"),
		oImg=oGod.doc.getElementById("bg"),
		oPoin=oGod.doc.getElementById("header"),
		oScore=oGod.doc.getElementById("score"),
		oHtime=oGod.doc.getElementById("htime"),
		oStop=oGod.doc.getElementById("begin"),
		oGameover=oGod.doc.getElementById("gameover"),
		oGamestart=oGod.doc.getElementById("gamestart"),
		oGamereset=oGod.doc.getElementById("gamereset"),
		oP=oGameover.getElementsByTagName("p"),
		oBtnover=oGameover.getElementsByTagName("span"),
		oBtnstart=oGamestart.getElementsByTagName("span"),
		oBtnreset=oGamereset.getElementsByTagName("span"),
		oMusic=oGod.doc.getElementsByTagName("audio"),

		oShare_f=oGod.doc.getElementById("share_f"),
		oShare_out=oGod.doc.getElementById("share_out"),
		oShare_close=oGod.doc.getElementById("share_close"),
		count=-1,
		girltimer=null,
		handtimer=null,
		overtimer=null,
		num=-1,
	//用于判断是否暂停
		goMove=false,
	//得分
		gScore=0,
	//游戏时间
		gameTime=30,
	//控制产生手的速度
		speedtime=1000,
	//声明一个控制所有咸猪手速度的变量
		globalSpeed=120;
	oShare_close.addEventListener("touchstart", function(){
		oShare_f.style.display="none";
	})
	oGameover.style.display="none";

	//样式初始化
	oImg.style.width=oGod.doc.documentElement.clientWidth+"px";
	oWrap.style.width=oGod.doc.documentElement.clientWidth+"px";
	oWrap.style.height=oGod.doc.documentElement.clientHeight+"px";	
	var handx=oImg.offsetWidth,
		handy=oImg.offsetHeight,
		bgWidth=oWrap.offsetWidth,
		bgHeight=oWrap.offsetHeight;

	//保证女神始终在屏幕中间
	oImg.style.top=(bgHeight-handy)/3+"px";

	oPoin.style.width=bgWidth+"px";
	

	oScore.style.fontSize=bgWidth/12+"px";
	oScore.style.marginLeft=bgWidth/48+"px";
	
	oHtime.style.fontSize=bgWidth/16+"px";
	oHtime.style.width=bgWidth/8+"px";
	oHtime.style.lineHeight=(bgWidth/48)*5+"px";

	oStop.style.fontSize=bgWidth/16+"px";
	oStop.style.marginRight=bgWidth/48+"px";
	oStop.style.marginLeft=bgWidth/16+"px";
	oStop.style.width=bgWidth/6+"px";
	oStop.style.lineHeight=bgWidth/11+"px";

	//判断是否横屏
	if(bgWidth>bgHeight){
		oGameover.style.fontSize=(bgHeight/40)*3+"px";
		oWrap.style.background="url(img/bg_two.jpg) 0 0 no-repeat";
		oWrap.style.backgroundSize="100% 100%";
		oImg.style.zIndex=-3000;
		oGamestart.style.fontSize=(bgHeight/40)*3+"px";
		oGamereset.style.fontSize=(bgHeight/40)*5+"px";
		oPoin.style.height=bgWidth/10-bgWidth/80+"px";
		oPoin.style.paddingTop=bgWidth/80+"px";

		oScore.style.fontSize=bgHeight/12+"px";
		oScore.style.marginLeft=bgHeight/48+"px";
	
		oHtime.style.fontSize=bgHeight/16+"px";
		oHtime.style.width=bgHeight/8+"px";
		oHtime.style.lineHeight=(bgHeight/48)*5+"px";

		oStop.style.fontSize=bgHeight/16+"px";
		oStop.style.marginRight=bgHeight/48+"px";
		oStop.style.marginLeft=bgHeight/16+"px";
		oStop.style.width=bgHeight/6+"px";
		oStop.style.lineHeight=bgHeight/11+"px";

		oShare_f.style.paddingTop=bgHeight*0.3+"px";
		oShare_out.style.width=bgHeight*0.8+"px";
		oShare_close.style.fontSize=bgHeight/16+"px";
	}
	else{
		oImg.style.zIndex=88;
		oGameover.style.fontSize=(bgWidth/40)*3+"px";
		oWrap.style.background="url(img/wrap_bg.jpg) 0 0 no-repeat";
		oWrap.style.backgroundSize="100% 100%";
		oGamestart.style.fontSize=(bgWidth/40)*3+"px";
		oGamereset.style.fontSize=(bgWidth/40)*5+"px";
		oPoin.style.height=bgHeight/10-bgHeight/80+"px";
		oPoin.style.paddingTop=bgHeight/80+"px";
		oScore.style.fontSize=bgWidth/12+"px";
		oScore.style.marginLeft=bgWidth/48+"px";

		oHtime.style.fontSize=bgWidth/16+"px";
		oHtime.style.width=bgWidth/8+"px";
		oHtime.style.lineHeight=(bgWidth/48)*5+"px";

		oStop.style.fontSize=bgWidth/16+"px";
		oStop.style.marginRight=bgWidth/48+"px";
		oStop.style.marginLeft=bgWidth/16+"px";
		oStop.style.width=bgWidth/6+"px";
		oStop.style.lineHeight=bgWidth/11+"px";

		oShare_f.style.paddingTop=bgHeight*0.3+"px";
		oShare_out.style.width="80%";
		oShare_close.style.fontSize=bgWidth/16+"px";
	}
	oGameover.style.width=bgWidth+"px";
	oGameover.style.height=bgHeight+"px";
	oGameover.style.paddingTop=bgHeight/4+"px";
	

	oGamestart.style.width=bgWidth+"px";
	oGamestart.style.height=bgHeight+"px";
	oGamestart.style.paddingTop=bgHeight/4+"px";
	

	oGamereset.style.width=bgWidth+"px";
	oGamereset.style.height=bgHeight+"px";
	oGamereset.style.paddingTop=bgHeight/5+"px";
	
	for (var i = 0; i < oBtnover.length; i++) {
		oBtnover[i].style.fontSize=(bgWidth/40)*2+"px";
		oBtnover[i].style.paddingLeft=(bgWidth/40)*2+"px";
		oBtnover[i].style.paddingRight=(bgWidth/40)*2+"px";
		oBtnover[i].style.marginTop=bgWidth/20+"px";
		oBtnover[i].style.lineHeight=bgHeight/10+"px";
	};
	for (var i = 0; i < oBtnstart.length; i++) {
		oBtnstart[i].style.fontSize=(bgWidth/40)*2+"px";
		oBtnstart[i].style.paddingLeft=(bgWidth/40)*2+"px";
		oBtnstart[i].style.paddingRight=(bgWidth/40)*2+"px";
		oBtnstart[i].style.lineHeight=bgHeight/10+"px";

	};
	oBtnstart[0].style.marginTop=bgHeight/8+"px";
	oBtnstart[1].style.marginTop=bgHeight/20+"px";

	for (var i = 0; i < oBtnreset.length; i++) {
		oBtnreset[i].style.fontSize=(bgWidth/40)*2+"px";
		oBtnreset[i].style.paddingLeft=(bgWidth/40)*2+"px";
		oBtnreset[i].style.paddingRight=(bgWidth/40)*2+"px";
		oBtnreset[i].style.marginTop=bgWidth/30+"px";
		oBtnreset[i].style.lineHeight=bgHeight/10+"px";
	};
	//阻止划屏
	document.addEventListener('touchstart', function(e){
		e.preventDefault();
	}, false)
	
	//游戏开始
	oBtnstart[0].addEventListener('touchstart', function(){
		goMove=true;
		oGamestart.style.display="none";
		gameReady();
		} ,false)
	

	//游戏暂停
	oStop.addEventListener('touchstart', function(){
		goMove=false;
			oGamereset.style.display="block";
		} ,false)

	//继续游戏
	oBtnreset[0].addEventListener('touchstart', function(){
		goMove=true;
		oGamereset.style.display="none";
		} ,false)

	//重新开始
	oBtnover[0].addEventListener('touchstart', function(){
		gScore=0;
		gameTime=30;
		speedtime=1000;
		globalSpeed=100;
		oScore.innerText="得分:"+0;
		oHtime.innerHTML=30;
		goMove=true;
		oGameover.style.display="none";
		gameReady();
		} ,false)
	if(bgWidth>bgHeight){
		//身体连线
	var girlArr=[[bgWidth*0.82,0],
	[bgWidth*0.68,bgHeight*0.26],[bgWidth*0.61,bgHeight*1],
	[bgWidth*0.43,bgHeight*1],[bgWidth*0.35,bgHeight*0.3],
	[bgWidth*0.2,0]]

	//咸猪手初始位置(左边，下边，右边)
	var getHandArr=[[-bgWidth/6,(bgHeight/8)*1],
	[-bgWidth/6,(bgHeight/8)*3],[-bgWidth/6,(bgHeight/8)*4],
	[-bgWidth/6,(bgHeight/8)*6],[bgWidth,(bgHeight/8)*1],
	[bgWidth,(bgHeight/8)*3],[bgWidth,(bgHeight/8)*4],
	[bgWidth,(bgHeight/8)*6]]

	//咸猪手目标
	var targetArr=[[bgWidth/2,bgHeight/3]];
	}
	else{
	//身体连线
	var girlArr=[[handx*0.521,oImg.offsetTop+handy*0.155],
	[handx*0.563,oImg.offsetTop+handy*0.263],[handx*0.72,oImg.offsetTop+handy*0.325],
	[handx*0.58,oImg.offsetTop+handy*0.4],[handx*0.552,oImg.offsetTop+handy*0.588],
	[handx*0.521,oImg.offsetTop+handy*0.838],[handx*0.5,oImg.offsetTop+handy*0.838],
	[handx*0.469,oImg.offsetTop+handy*0.625],[handx*0.42,oImg.offsetTop+handy*0.4],
	[handx*0.28,oImg.offsetTop+handy*0.331],[handx*0.448,oImg.offsetTop+handy*0.263],
	[handx*0.479,oImg.offsetTop+handy*0.156]]

	//咸猪手初始位置(左边，下边，右边)
	var getHandArr=[[-handx/6,(handy/8)*1],[-handx/6,(handy/8)*2],
	[-handx/6,(handy/8)*3],[-handx/6,(handy/8)*4],[-handx/6,(handy/8)*5],
	[-handx/6,(handy/8)*6],[-handx/6,(handy/8)*7],[handx,(handy/8)*1],
	[handx,(handy/8)*2],[handx,(handy/8)*3],[handx,(handy/8)*4],
	[handx,(handy/8)*5],[handx,(handy/8)*6],[handx,(handy/8)*7]]
	
	//咸猪手目标
	var targetArr=[[handx/2,oImg.offsetTop+handy/3]];
	}

	

	
//游戏开始的函数
function gameReady(){
		//女孩不停移动
		girltimer=setInterval(function(){
		if(goMove){
		count++;
		if(count>7){
			count=0
		}
		oImg.src="img/touchme"+count+".png"
		}
		
	},200)

	//时间的定时器
	overtimer=setInterval(function(){
		if(goMove){
			gameTime--;
			oHtime.innerHTML=gameTime;
			switch(gameTime){
				case 25:
				globalSpeed=80;
				break;

				case 20:
				globalSpeed=60;
				break;
				
				case 15:
				globalSpeed=40;
				break;
				
				case 10:
				globalSpeed=30;
				break;
				
				case 5:
				globalSpeed=20;
				break;
				
				case 0:
				gameover();
				break;
			}
		}		
	},1000)
	//生成咸猪手的定时器;
	handtimer=setInterval(function(){
		if(goMove){
			Hand();
		}		
	},500)
	}

	//构造咸猪手
	function Hand(){
		var getRan=parseInt(Math.random()*getHandArr.length);
		//保证咸猪手不在同一个地方重复生成
		while(getRan==num){
			getRan=parseInt(Math.random()*getHandArr.length)
		}
		num=getRan;
		var oLi=oGod.doc.createElement("li");
		if(getRan<(girlArr.length/2+1)){
			oLi.style.background="url(img/right_hand.png) 0 0 no-repeat"
		}
		else{
			oLi.style.background="url(img/left_hand.png) 0 0 no-repeat"
		}
		oLi.style.backgroundSize="100% 100%"
		oLi.className="hand";
		oLi.style.width=handx/6+"px";
		oLi.style.height=(handx/9)*2+"px";
		oWrap.insertBefore(oLi, oGameover);
		oLi.style.left=getHandArr[getRan][0]+"px";
		oLi.style.top=getHandArr[getRan][1]+"px";
		//移动的速度
		var x=(targetArr[0][0]-oLi.offsetLeft)/globalSpeed;
		var y=(targetArr[0][1]-oLi.offsetTop)/globalSpeed;
		x=x>0?Math.ceil(x):Math.floor(x)
		y=y>0?Math.ceil(y):Math.floor(y)

		oLi.addEventListener('touchstart', function(){
			gScore++;
			oWrap.removeChild(this);
			this.timer=null;
			oScore.innerText="得分:"+gScore;
			oMusic[0].currentTime=0;
			oMusic[0].play();
		} ,false)

		//定义一个咸猪手的定时器
		oLi.timer=setInterval(function(){
			if(goMove){
			oLi.style.left=oLi.offsetLeft+x+"px";
            oLi.style.top=oLi.offsetTop+y+"px";

            //定义一个数组存放oLi的四个点坐标
			oLi.handArr=[[oLi.offsetLeft,oLi.offsetTop],[oLi.offsetLeft+oLi.offsetWidth,oLi.offsetTop],
			[oLi.offsetLeft,oLi.offsetTop+oLi.offsetHeight],[oLi.offsetLeft+oLi.offsetWidth,oLi.offsetTop+oLi.offsetHeight]];

			//检测碰撞
			moveOver(oLi);
			}
           
		},50)
	}

//碰撞检测
function moveOver(obj){

			for (var a = 0; a < obj.handArr.length; a++) {
				var b=a+1;
				if(b==obj.handArr.length){
					b=0;
					}
				for (var c = 0; c < girlArr.length; c++) {
					var d=c+1;
					if(d==girlArr.length){
						d=0;
					}
					if(oGod.contact(obj.handArr[a][0],obj.handArr[a][1],
						obj.handArr[b][0],obj.handArr[b][1],
						girlArr[c][0],girlArr[c][1],
						girlArr[d][0],girlArr[d][1])){
							gameover();

							oMusic[1].play()
						}

					};

			};
			
		}
	//游戏结束的函数
function gameover(){
	clearInterval(girltimer)
	clearInterval(handtimer)
	clearInterval(overtimer)
	var timer=setInterval(function(){
		var oChild=oWrap.getElementsByTagName("li");
		if(oChild.length>0){
			for (var i = 0; i < oChild.length; i++) {
			clearInterval(oChild[i].timer);	
			oWrap.removeChild(oChild[i]);					
			};
		}
		else{
			clearInterval(timer)
		}
			
	},0)
		
	oGameover.style.display="block";		
	oP[0].innerHTML="我防止女神被骚扰"+gScore+"次,"
	var overScore=parseInt((gScore/87)*100)
	oP[1].innerHTML="打败了"+overScore+"%的勇士,"
	if(overScore>50){
		var score_a=parseint(overScore/10)
		oP[2].innerHTML=oGod.overstr[score_a]
	}
	else{
		oP[2].innerHTML="女神狠狠的鄙视了我！"
	}
	
	}

},

//向量积检测
contact:function(ax,ay,bx,by,cx,cy,dx,dy){
			var linex1=(bx-ax)*(cy-ay)-(cx-ax)*(by-ay);
			var linex2=(bx-ax)*(dy-ay)-(dx-ax)*(by-ay);
			var liney1=(ax-cx)*(dy-cy)-(dx-cx)*(ay-cy);
			var liney2=(bx-cx)*(dy-cy)-(dx-cx)*(by-cy);
			if (linex1*linex2<0&&liney1*liney2<0) {
				return true;
			};
		},
//分享
share:function(){
	var share_btn=document.getElementsByClassName("share");
	for (var i = 0; i < share_btn.length; i++) {
		share_btn[i].addEventListener("touchstart",function(){
			var oShare_f=document.getElementById("share_f");
			oShare_f.style.display="block";
		})
	};
}
}

window.onload=function(){
	oGod.goReady();
	oGod.share()
}
//屏幕改变时
window.onresize=function(){
	window.location.href=window.location.href
}
